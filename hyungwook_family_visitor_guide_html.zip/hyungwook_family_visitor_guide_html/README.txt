형욱·휘연·로아·시안이네 집 방문 안내 HTML

1. index.html을 열면 브라우저에서 바로 확인할 수 있습니다.
2. 공유용 웹주소로 제공하려면 이 폴더 전체를 GitHub Pages, Cloudflare Pages, Netlify 등 정적 웹 호스팅에 업로드하세요.
3. assets 폴더와 index.html의 상대 위치를 변경하지 마세요.
4. 내비게이션 링크, 사진 확대, 주차 경로 선택, 하단 메뉴가 포함되어 있습니다.
